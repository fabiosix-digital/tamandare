<?php
// Silêncio é ouro